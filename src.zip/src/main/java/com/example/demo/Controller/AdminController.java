package com.example.demo.Controller;

import com.example.demo.Model.Admin;
import com.example.demo.Repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admins")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private AdminRepository adminRepository;

    @PostMapping("/login")
    public boolean login(@RequestBody Admin admin) {
        Admin existing = adminRepository.findByAdminIdAndPassword(
            admin.getAdminId(), admin.getPassword()
        );
        return existing != null;
    }
}
