package com.example.demo.Controller;

import com.example.demo.Model.OrderItem;
import com.example.demo.Model.Product;
import com.example.demo.Model.User;
import com.example.demo.Repository.OrderItemRepository;
import com.example.demo.Repository.ProductRepository;
import com.example.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class OrderController {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private OrderItemRepository orderItemRepo;

    @Autowired
    private ProductRepository productRepo;

    @PostMapping
    public String placeOrder(@RequestBody OrderRequest request) {
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setAddress(request.getAddress());
        User savedUser = userRepo.save(user);

        for (OrderItem item : request.getItems()) {
            item.setOrderid(savedUser.getOrderid());
            orderItemRepo.save(item);

            Product product = productRepo.findById((long)item.getProductId()).orElse(null);
            if (product != null) {
                product.setStock(product.getStock() - item.getQuantity());
                productRepo.save(product);
            }
        }

        return "Order placed successfully!";
    }
}
