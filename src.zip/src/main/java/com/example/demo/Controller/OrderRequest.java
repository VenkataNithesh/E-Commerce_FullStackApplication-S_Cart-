package com.example.demo.Controller;

import com.example.demo.Model.OrderItem;
import java.util.List;

public class OrderRequest {
    private String name;
    private String email;
    private String address;
    private List<OrderItem> items;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public List<OrderItem> getItems() { return items; }
    public void setItems(List<OrderItem> items) { this.items = items; }
}
